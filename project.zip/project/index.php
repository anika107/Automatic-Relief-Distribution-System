<?php session_start(); ?>
  
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="http://fonts.googleapis.com/css?family=Didact+Gothic" rel="stylesheet" />
	<link href="default.css" rel="stylesheet" type="text/css" media="all" />
	<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
	<title>project</title>
</head>

<body>
    <div id="header-wrapper">
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="http://localhost/project/index.php">Project</a></h1>
                <h3>Corona</h3>
            </div>
        
            <?php if (isset($_SESSION['logged'])) { ?>
                <div id="menu">
                    <ul>
                        <li class="active"><a href="http://localhost/project/index.php">Homepage</a></li>
                        <li><a href="http://localhost/project/relief.php">Latest Update</a></li>
                        <li><a href="http://localhost/project/logout.php">Log Out</a></li>
                    </ul>
                </div>
            </div>
        </div>
    
    <div id="wrapper">
        <div id="three-column" class="container">
            <div class="title">
                <h2>One Stop Service For All</h2>
            </div>
            <div class="boxA">
                <p>Keep all information organized by entering the records on time. Click below to enter new Disaster information.</p>
                <a href="disasterEntryForm.php" class="button button-alt">Disaster Record Form</a>
            </div>
            <div class="boxB">
                <p>Keep all information organized by entering the records on time. Click below to enter new Victim information.</p>
                <a href="victimEntryForm.php" class="button button-alt">Victim Record Form</a>
            </div>
            <div class="boxC">
                <p>Keep all information organized by entering the records on time. Click below to look for victims.</p>
                <a href="vsearch.php" class="button button-alt">Search For A Victim</a>
            </div>
        </div>
    </div>

            <?php } else { ?>
                <div id="menu">
                    <ul>
                        <li class="active"><a href="http://localhost/project/index.php">Homepage</a></li>
                        <li><a href="http://localhost/project/login.php">Log In</a></li>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </div>
    
    <div id="copyright" class="container">
	   <p>&copy; project. All rights reserved.</p>
    </div>

</body>
</html>