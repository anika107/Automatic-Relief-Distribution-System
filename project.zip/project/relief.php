<?php session_start(); ?>
  
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="http://fonts.googleapis.com/css?family=Didact+Gothic" rel="stylesheet" />
	<link href="default.css" rel="stylesheet" type="text/css" media="all" />
	<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" type="text/css" href="http://localhost/project/cssTable/util.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/project/csstable/main.css">
	<title>Latest Update</title>
</head>

<body>
    <div id="header-wrapper">
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="http://localhost/project/index.php">Project</a></h1>
                <h3>Corona</h3>
            </div>
        
            <?php if (isset($_SESSION['logged'])) { ?>
                <div id="menu">
                    <ul>
                        <li><a href="http://localhost/project/index.php">Homepage</a></li>
                        <li class="active"><a href="http://localhost/project/relief.php">Latest Update</a></li>
                        <li><a href="http://localhost/project/logout.php">Log Out</a></li>
                    </ul>
                </div>
            </div>
			
        </div>
		
		<div id="wrapper">
			<div id="three-column" class="container">
				<div class="title">
					<h2>Distribution of Clothing Relief</h2>
					<p>Will enter three tables: total relief, clothes, medicine and whatever.</p>
				</div>
        
				<div class="table100 ver5 m-b-110">
					<table data-vertable="ver5">
						<thead>
							<tr class="row100 head">
								<th class="column100 column1" data-column="column1">Total Active Case</th>
								<th class="column100 column1" data-column="column2">Total Recover Case</th>
								<th class="column100 column1" data-column="column3">Total Death</th>
							</tr>
						</thead>
						<tbody>
							<?php
								$db = mysqli_connect("localhost", "root", "", "quarintined");
								if (!$db)	die("Connection failed: " . mysqli_connect_error());

								$sql1 = "SELECT COUNT(*)FROM affected WHERE status = 'affected'";
								$sql2 = "SELECT COUNT(*)FROM affected WHERE status = 'recovered'";
								$sql3 = "SELECT COUNT(*)FROM affected WHERE status = 'dead'";
								$result1 = mysqli_query($db, $sql1);
								$result2 = mysqli_query($db, $sql2);
								$result3 = mysqli_query($db, $sql3);

								if (mysqli_num_rows($resul1) > 0) {
									while($row = mysqli_fetch_assoc($result)) {	
										echo '<tr class="row100">';
										echo '<td class="column100 column1" data-column="column1">' . $row[$result1] . "</td>";
										echo '<td class="column100 column1" data-column="column2">' . $row[$result2] . "</td>";
										echo '<td class="column100 column1" data-column="column3">' . $row[$result3] . "</td>";
										echo "</tr>";
									}
								}

								mysqli_close($db);
							?>
						</tbody>
					</table>
				</div>	
			</div>

    
		
           
		<?php } else { ?>
                <div id="menu">
                    <ul>
                        <li class="active"><a href="http://localhost/project/index.php">Homepage</a></li>
                        <li><a href="http://localhost/project/login.php">Log In</a></li>
                    </ul>
                </div>
            <?php } ?>
        </div>
    </div>
    
    <div id="copyright" class="container">
	   <p>&copy; project. All rights reserved.</p>
    </div>

</body>
</html>